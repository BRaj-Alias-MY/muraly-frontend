import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-display-exams',
  templateUrl: './display-exams.component.html',
  styleUrls: ['./display-exams.component.css']
})
export class DisplayExamsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
