import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BulkuserComponent } from './bulkuser.component';

describe('BulkuserComponent', () => {
  let component: BulkuserComponent;
  let fixture: ComponentFixture<BulkuserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BulkuserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BulkuserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
