import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";
import { HttpClient, HttpEventType, HttpResponse } from "@angular/common/http";
import { FileDownloaderService } from "./file-downloader.service";
declare var $: any;
declare var myImage: any;
import { ApiService } from '../../../services/api.service';
import { Router } from '@angular/router';
@Component({
  selector: "app-testmysetup2",
  templateUrl: "./testmysetup2.component.html",
  styleUrls: ["./testmysetup2.component.css"]
})
export class Testmysetup2Component implements OnInit {
  bandwidth: boolean = false;
  startprocess: any = false;
  @ViewChild("video")
  public video: ElementRef;
  @ViewChild("audio")
  public audio: ElementRef;
  myImage: any;
  constructor(
    private api: ApiService, private router: Router,
    private http: HttpClient,
    private downloader: FileDownloaderService
  ) { }

  selectedVideoDevice: string;
  selectedAudioDevice: string;
  selectedBrowser: string;
  selectedOs: string;
  showText: boolean;
  videos: boolean;
  percentDone: number;
  startTime: any;
  endTime: any;
  currTime: any;
  prevTime: any;
  speed: number = 0;
  bytesReceied: number = 0;
  oldbytes: number = 0;
  unit: string = "Mbps";
  browser: string;
  os: string;
  audios: boolean;
  showError: boolean;
  canJoinMeeting: boolean;
  browserstatus: boolean;
  osstatus: boolean;
  canStopTest: boolean;
  errorMessage: string;

  availableVideoDevices: Array<{ deviceId: string; name: string }>;
  availableAudioDevices: Array<{ deviceId: string; name: string }>;
  availableBrowsers: Array<{ deviceId: string; name: string }>;
  myvalue() {

    let value = localStorage.getItem('band');
    //alert(value);
    if (value == 'true') {
      // alert(value);
      this.bandwidth = true;
    }
    else {
      this.bandwidth = false;
    }

  }
  testaudio() {
    let value = localStorage.getItem('band');
    alert('hi' + value + '/' + this.audios);
  }
  startnow() {
    if (this.bandwidth == true && this.audios == true && this.videos == true) {
      this.startprocess = true;
    }
    console.log(this.bandwidth + '/' + this.audios + this.videos);
  }
  public ngOnInit() {
    localStorage.setItem('band', '');
    //javascript code 
    /*
    Written by Suman Bogati 
    sumanbogati@gmail.com
    */
    let band = false;
    localStorage.setItem('band', '');
    var bandWidthSpeed = {
      downloadSize: 1500000, //1MB

      measure: function (cb) {
        var myImage = new Image();
        var that = this;
        myImage.onload = function () {
          that.endTime = (new Date()).getTime();
          var speedKbps = that.calculate();
          cb(speedKbps);
        }
        /*
                myImage.onerror = function (err, msg) {
                  console.log("Invalid image, or error downloading");
                }
        */
        this.startTime = (new Date()).getTime();
        var cacheBuster = "?nnn=" + this.startTime; // everytime the page is refrsh, the browser treat the image file as new file
        myImage.src = "https://raw.githubusercontent.com/sumanbogati/images/master/jstutorial/bandwidth-test.jpg" + cacheBuster;
        console.log('Image Src ' + myImage.src);
      },

      /* calculate the bandwidth speed based on start and end time of image-downloaded process */
      calculate: function () {
        let duration = (this.endTime - this.startTime) / 1000;
        let bitsLoaded = this.downloadSize * 8;
        let speedBps = (bitsLoaded / duration).toFixed(2);
        let speedKbps = (parseInt(speedBps) / 1024).toFixed(2);
        return Math.round(parseInt(speedKbps));
      }
    }

    /** Initialize the process to bandwidth checking **/
    document.getElementById('bandWidthCheck').addEventListener('click', function () {
      $('#bandWidthSpped').show();
      $('.loader').show();
      $('#check').show();
      localStorage.setItem('band', '');
      var result = document.querySelector("#bandWidthSpped .result");
      result.innerHTML = "";
      bandWidthSpeed.measure(function (speedKbps) {



        band = true;
        if (speedKbps > 200) {
          $('#check').hide();
          result.innerHTML = '<div style="width:92%" class="alert alert-success"><strong>Success!</strong> Network Speed Test Passed.</div>';

          localStorage.setItem('band', String(band));
          $('#myclick').trigger('click');
          $('.loader').hide();
          setTimeout(function () {
            $('#bandWidthSpped').fadeOut(1000);
          }, 2000);

        }
        else {
          console.log("speed :" + speedKbps);

          $('.loader').hide();
          result.innerHTML = '<div  style="width:92%" class="alert alert-danger"><strong>Network is slow!</strong> Unable to process right now. Network Speed should be more than 1000kbps. </div>';
          setTimeout(function () {
            $('#bandWidthSpped').fadeOut(1000);
          }, 2000);
        }
      });

    }

    );


    //end javascript code 
    this.showText = false;
    this.showError = false;
    this.canStopTest = false;
    this.canJoinMeeting = true;
    this.browserstatus = false;
    this.osstatus = false;
    this.videos = false;
    this.audios = false;
    this.availableVideoDevices = [];
    this.availableAudioDevices = [];
    this.availableBrowsers = [];
    this.selectedBrowser = undefined;
    this.selectedVideoDevice = undefined;
    this.selectedAudioDevice = undefined;
    this.browser = undefined;
    this.browserstatus = undefined;
    this.osstatus = undefined;
    this.os = undefined;
    this.detectDevices();

    this.startnow();
  }

  private detectVideo() {
    navigator.mediaDevices
      .enumerateDevices()
      .then(devices => {
        devices.forEach(device => {
          if (device.kind === "videoinput") {
            if (!this.selectedVideoDevice) {
              this.selectedVideoDevice = device.deviceId;
            }
            this.videos = true;
            this.startnow();
            this.availableVideoDevices.push({
              deviceId: device.deviceId,
              name:
                device.label ||
                `camera ${this.availableVideoDevices.length + 1}`
            });
          }
        });
      })
      .catch(error => this.handleError(error));
  }
  private detectAudio() {
    $('.loader1').show();
    navigator.mediaDevices
      .enumerateDevices()
      .then(devices => {
        devices.forEach(device => {
          if (device.kind === "audioinput") {
            if (!this.selectedAudioDevice) {
              this.selectedAudioDevice = device.deviceId;
            }
            this.audios = true;
            $('.loader1').hide();
            this.availableAudioDevices.push({
              deviceId: device.deviceId,
              name:
                device.label ||
                `microphone ${this.availableAudioDevices.length + 1}`
            });
          }
        });
      })
      .catch(error => this.handleError(error));
  }
  private detectDevices() {
    navigator.mediaDevices
      .enumerateDevices()
      .then(devices => {
        devices.forEach(device => {
          this.selectedBrowser = navigator.vendor;
          if (navigator.vendor) {
            this.browser = window.navigator.vendor;
            this.browserstatus = true;
          }
          this.selectedBrowser = navigator.platform;
          if (navigator.platform) {
            this.os = window.navigator.platform;
            this.osstatus = true;
          }
        });
      })
      .catch(error => this.handleError(error));
  }

  ondetect() {
    this.onStart();
  }
  onStart() {
    this.startAudio();
    this.startVideo();
    this.detectAudio();
    this.detectDevices();
    this.detectVideo();
    this.download();
    this.detectDevices();
    this.canStopTest = true;
  }
  onstop() {
    this.stopTest();
  }
  onVideoDeviceChange(videoDevice) {
    this.selectedVideoDevice = videoDevice;
    this.canJoinMeeting = true;
  }
  onAudioDeviceChange(audioDevice) {
    this.selectedAudioDevice = audioDevice;
    this.canJoinMeeting = true;
  }
  startVideo() {
    $('.loader2').show();
    this.showError = true;
    const audioSource = this.selectedAudioDevice;
    const videoSource = this.selectedVideoDevice;
    const browserSource = this.selectedBrowser;
    const constraints = {
      audio: { deviceId: audioSource ? { exact: audioSource } : undefined },
      video: { deviceId: videoSource ? { exact: videoSource } : undefined },
      browser: {
        deviceId: browserSource ? { exact: browserSource } : undefined
      }
    };
    if (
      navigator.mediaDevices &&
      navigator.mediaDevices.getUserMedia &&
      navigator.onLine &&
      navigator.userAgent
    ) {
      navigator.mediaDevices
        .getUserMedia(constraints)
        .then(stream => {
          this.video.nativeElement.srcObject = stream;
          this.video.nativeElement.muted = true;
          this.video.nativeElement.play();
          this.showText = false;
          this.videos = true;
          this.startnow();
          $('.loader2').hide();
          this.canJoinMeeting = true;
          this.canStopTest = true;
        })
        .catch(error => this.handleError(error));
    } else {
      this.canStopTest = false;
      alert(
        "Something went wrong!Your Equipment is not Working Properly You Cannot Go To Take Interview"
      );
    }
  }
  startAudio() {
    this.showError = true;
    const audioSource = this.selectedAudioDevice;
    //const videoSource = this.selectedVideoDevice;
    const browserSource = this.selectedBrowser;
    const constraints = {
      audio: { deviceId: audioSource ? { exact: audioSource } : undefined },
      //video: { deviceId: videoSource ? { exact: videoSource } : undefined },
      browser: {
        deviceId: browserSource ? { exact: browserSource } : undefined
      }
    };
    if (
      navigator.mediaDevices &&
      navigator.mediaDevices.getUserMedia &&
      navigator.onLine &&
      navigator.userAgent
    ) {
      navigator.mediaDevices
        .getUserMedia(constraints)
        .then(stream => {
          this.audio.nativeElement.srcObject = stream;
          //this.audio.nativeElement.muted = false;
          //this.audio.nativeElement.play();
          this.showText = false;
          this.canJoinMeeting = true;
          this.audios = true;
          this.canStopTest = true;
        })
        .catch(error => this.handleError(error));
    } else {
      this.canStopTest = false;
      alert(
        "Something went wrong!Your Equipment is not Working Properly You Cannot Go To Take Interview"
      );
    }
  }
  // startTest() {
  //   this.showError = false;
  //   const audioSource = this.selectedAudioDevice;
  //   const videoSource = this.selectedVideoDevice;
  //   const browserSource = this.selectedBrowser;
  //   const constraints = {
  //     audio: { deviceId: audioSource ? { exact: audioSource } : undefined },
  //     video: { deviceId: videoSource ? { exact: videoSource } : undefined },
  //     browser: { deviceId: browserSource ? { exact: browserSource } : undefined }
  //   };
  //   if (
  //     navigator.mediaDevices &&
  //     navigator.mediaDevices.getUserMedia &&
  //     navigator.userAgent
  //   ) {
  //     navigator.mediaDevices
  //       .getUserMedia(constraints)
  //       .then(stream => {
  //         this.video.nativeElement.srcObject = stream;
  //         this.video.nativeElement.muted = true;
  //         this.video.nativeElement.play();
  //         this.audio.nativeElement.play();
  //         const audioContext = new AudioContext();
  //         const analyser = audioContext.createAnalyser();
  //         //const microphone = audioContext.createMediaStreamSource(stream);
  //         const javascriptNode = audioContext.createScriptProcessor(2048, 1, 1);

  //         analyser.smoothingTimeConstant = 0.8;
  //         analyser.fftSize = 1024;

  //         this.audio.nativeElement.connect(analyser);
  //         analyser.connect(javascriptNode);
  //         javascriptNode.connect(audioContext.destination);
  //         javascriptNode.onaudioprocess = function() {
  //           const array = new Uint8Array(analyser.frequencyBinCount);
  //           analyser.getByteFrequencyData(array);
  //           let values = 0;

  //           const length = array.length;
  //           for (let i = 0; i < length; i++) {
  //             values += array[i];
  //           }

  //           const average = values / length;

  //           console.log(Math.round(average));
  //           //colorPids(average);
  //           const all_pids = $(".pid");
  //           const amout_of_pids = Math.round(average / 10);
  //           const elem_range = all_pids.slice(0, amout_of_pids);
  //           for (let i = 0; i < all_pids.length; i++) {
  //             all_pids[i].style.backgroundColor = "#e6e7e8";
  //           }
  //           for (let i = 0; i < elem_range.length; i++) {
  //             console.log(elem_range[i]);
  //             elem_range[i].style.backgroundColor = "#69ce2b";
  //           }
  //           // canvasContext.clearRect(0, 0, 150, 300);
  //           // canvasContext.fillStyle = "#BadA55";
  //           // canvasContext.fillRect(0, 300 - average, 150, 150);
  //           // canvasContext.fillStyle = "#262626";
  //           // canvasContext.font = "48px impact";
  //           // canvasContext.fillText(Math.round(average - 40), -2, 300);
  //         };
  //         this.showText = true;
  //         this.canJoinMeeting = false;
  //         this.canStopTest = true;
  //       })
  //       .catch(error => this.handleError(error));
  //   } else {
  //     this.canStopTest = false;
  //     alert("Please check your equipment if Working Properly");
  //   }
  // }

  stopTest() {
    this.showError = false;
    // const stream = this.video.nativeElement.srcObject;
    // const tracks = stream.getTracks();
    // tracks.forEach(function (track) {
    //   track.stop();
    // })
    this.video.nativeElement.srcObject = null;
    this.showText = true;
    this.canJoinMeeting = false;
    this.canStopTest = false;
    alert("If You Can See Yourself Your Equipment is Working Sucessfully");
  }
  download() {
    this.downloader.download().subscribe(event => {
      if (event.type === HttpEventType.DownloadProgress) {
        this.percentDone = Math.round((100 * event.loaded) / event.total);
        console.log(`Downloaded speed  is ${this.percentDone}% downloaded.`);

        this.currTime = new Date().getTime();
        if (this.percentDone === 0) {
          this.startTime = new Date().getTime();
          this.prevTime = this.startTime;
        }

        this.bytesReceied = event.loaded / 1000000;
        console.log("bytesReceied", this.bytesReceied);
        this.speed =
          (this.bytesReceied - this.oldbytes) /
          ((this.currTime - this.prevTime) / 1000);
        if (this.speed < 1) {
          this.unit = "Kbps";
          this.speed *= 1000;
        } else this.unit = "Mbps";
        console.log("speed", this.speed + this.unit);
        console.log(this.prevTime);
        console.log(this.currTime);
        console.log("time", this.currTime - this.prevTime);
        this.prevTime = this.currTime;

        this.oldbytes = this.bytesReceied;
        console.log("oldbytes", this.oldbytes);
        console.log("\n");

        if (this.percentDone === 100) {
          this.endTime = new Date().getTime();
          let duration = (this.endTime - this.startTime) / 1000;
          let mbps = event.total / duration / 1000000;
          if (mbps < 1) {
            this.speed = event.total / duration / 1000;
            this.unit = "Kbps";
          } else {
            this.speed = mbps;
            this.unit = "Mbps";
          }
        }
      } else if (event instanceof HttpResponse) {
        var res: any = event.body;
        //console.log('start download:', res);
        var url = window.URL.createObjectURL(res);
        var a = document.createElement("a");
        document.body.appendChild(a);
        a.setAttribute("style", "display: none");
        a.href = url;
        //a.download = "SpeedTest_32MB.dat";
        // a.click();
        // window.URL.revokeObjectURL(url);
        // a.remove();
        // console.log("File is completely downloaded!");
      }
    });
  }
  private handleError(error) {
    this.showError = true;
    this.errorMessage = error.toString();
  }
  logout() {
    this.api.logout();
    this.router.navigate(['/login']);
  }
}
