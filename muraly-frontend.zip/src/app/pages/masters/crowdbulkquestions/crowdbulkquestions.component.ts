import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { MastersService } from '../services/masters.service';
import Swal from 'sweetalert2/dist/sweetalert2.js'

@Component({
  selector: 'app-crowdbulkquestions',
  templateUrl: './crowdbulkquestions.component.html',
  styleUrls: ['./crowdbulkquestions.component.css']
})
export class CrowdbulkquestionsComponent implements OnInit {

  public csvRecords: any[] = [];
	public csvRecords1 = [];
	constructor(private fb: FormBuilder, private route: Router, private api: MastersService) {}
	buttonStatus;
	responsedata;

	ngOnInit() {
		this.buttonStatus = false;
	}
	@ViewChild('fileImportInput') fileImportInput: any;
	fileChangeListener($event: any): void {
		var text = [];
		var files = $event.srcElement.files;

		if (this.isCSVFile(files[0])) {
			var input = $event.target;
			var reader = new FileReader();
			reader.readAsText(input.files[0]);

			reader.onload = (data) => {
				let csvData = reader.result;
				let csvRecordsArray = (csvData as string).split(/\r\n|\n/);

				let headersRow = this.getHeaderArray(csvRecordsArray);

				this.csvRecords = this.getDataRecordsArrayFromCSVFile(csvRecordsArray, headersRow.length);
			};

			reader.onerror = function() {
				Swal('Unable to read ' + input.files[0]);
			};
		} else {
			alert('Please import valid .csv file.');
			this.fileReset();
		}
	}
	getDataRecordsArrayFromCSVFile(csvRecordsArray: any, headerLength: any) {
		var dataArr = [];
		for (let i = 1; i < csvRecordsArray.length; i++) {
			//let data = (csvRecordsArray[i] as string).split(',');
			let data = csvRecordsArray[i].match(/("[^"]*")|[^,]+/g);

			if (data) {
				if (data.length == headerLength) {
					var csvRecord: CSVRecord = new CSVRecord();

					csvRecord.question = data[0].trim();
					csvRecord.expLevel = data[1].trim();
					csvRecord.difficulty = data[2].trim();
					csvRecord.domain = data[3].trim();
					csvRecord.subDomain = data[4].trim();
					csvRecord.keywords1 = data[5].trim();
					csvRecord.answer1 = data[6].trim();
					csvRecord.time = data[7].trim();
					csvRecord.answer = csvRecord.answer1.replace(/^"|"$/g, '');
					csvRecord.keywords = csvRecord.keywords1.replace(/^"|"$/g, '');
					dataArr.push(csvRecord);
					console.log(dataArr);
				}
			}
		}
		// console.log(dataArr);
		let dupStatus = false;
		for (let i = 0; i < dataArr.length; i++) {
			// console.log(dataArr[i].question);
			for (let j = i + 1; j < dataArr.length; j++) {
				if (dataArr[i].question == dataArr[j].question) {
					dupStatus = true;
					break;
				}
			}
		}
		if (dupStatus) {
			//Swal('Duplicate Data.');
		} else {
			//console.log(this.api.valid_question_temp);
			this.api.valid_question_temp(dataArr).subscribe((res) => {
				if (res.status) {
					this.buttonStatus = res.status;
					this.csvRecords1 = res.message;
					this.responsedata = res;
					this.fileReset();
				} else {
					this.csvRecords1 = res.message;
					 console.log(this.csvRecords1);
					 this.fileReset();
					 if(this.csvRecords1.length>0){
						Swal.fire('Oops..', 'Please find the Validation Column', 'error');
					 }else{
						Swal.fire('Oops..', 'No data found in file. please upload with valid data', 'error');
					 }

				}
			});
		}

		return dataArr;
	}

	isCSVFile(file: any) {
		return file.name.endsWith('.csv');
	}
	getHeaderArray(csvRecordsArr: any) {
		let headers = (csvRecordsArr[0] as string).split(',');
		let headerArray = [];

		for (let j = 0; j < headers.length; j++) {
			headerArray.push(headers[j]);
		}
		return headerArray;
	}

	fileReset() {
		this.fileImportInput.nativeElement.value = '';
		this.csvRecords = [];
	}

	onSubmit(data) {
		//alert('hi');
		console.log(data);
		this.api.save_question_temp(this.responsedata).subscribe((res) => {
			if (res.status) {
				Swal.fire('Success..', 'Questions Uploaded successfully', 'success'); 
				this.fileReset();
				this.csvRecords1 = [];
			} else {
				
         Swal.fire('Oops...', 'Something went wrong!', 'error');
			}
		});
	}
}
export class CSVRecord {
	public question: any;
	public expLevel: any;
	public difficulty: any;
	public domain: any;
	public subDomain: any;
	public keywords: any;
	public answer: any;
	public answer1: any;
	public keywords1: any;
	public time:any;
}
