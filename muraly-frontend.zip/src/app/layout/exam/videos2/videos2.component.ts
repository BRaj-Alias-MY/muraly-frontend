import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../app.service';
import { Router } from '@angular/router';
declare var $: any;
import { ApiService } from '../../../services/api.service';

@Component({
  selector: 'app-videos2',
  templateUrl: './videos2.component.html',
  styleUrls: ['./videos2.component.css']
})
export class Videos2Component implements OnInit {
  email = localStorage.getItem('email');
  currentInterviewId = localStorage.getItem('currentInterview');
  videosList = [];
  videoURLs: any;
  constructor(private api: ApiService, private service: AppService, private router: Router) { }

  ngOnInit() {
    this.getVideos();
    $(document).ready(function () {
      $('ul li a').first().trigger('click');

    });
  }

  getVideos() {
    //alert(this.email);
    this.service.getVideos(this.email, parseInt(this.currentInterviewId)).subscribe(resp => { console.log('hi'); console.log(resp); this.videosList = resp; }, err => console.log(err));

  }
  gotoHome() {
    this.router.navigate(['/examboard/entrypage']);
  }
  logout() {
    this.api.logout();
    this.router.navigate(['/login']);
  }

}
