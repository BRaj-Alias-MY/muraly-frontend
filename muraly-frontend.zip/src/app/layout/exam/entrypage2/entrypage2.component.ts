import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../app.service';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Dialog1Component } from '../dialog1/dialog1.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ApiService } from '../../../services/api.service';
@Component({
  selector: 'app-entrypage',
  templateUrl: './entrypage2.component.html',
  styleUrls: ['./entrypage2.component.css']
})
export class Entrypage2Component implements OnInit {
  interviews = [];
  pin: any;
  pinResponse = [];
  myForm: FormGroup;
  Verifypin = 'Verify PIN';

  status = localStorage.getItem('status');
  pin2 = localStorage.getItem('pin');
  email = localStorage.getItem('email');
  domain = localStorage.getItem('domain');
  subdomain = localStorage.getItem('subdomain');

  constructor( private api:ApiService, private router: Router, private dialog: MatDialog, private service: AppService) {
    this.myForm = this.myFormGroup();
  }

  ngOnInit() {
    localStorage.setItem('profile', 'no');
    this.getInterview();
  }


  openDialog() {
    /*
    this.dialog.open(Dialog1Component, {
      width: '90%'

    });
    */


  }


  getInterview() {

    const email = localStorage.getItem('email');
    //alert(this.email + this.domain + this.subdomain);
    this.service.getInterviews()
      .subscribe(resp => { this.interviews = resp; console.log(resp) }, err => console.log(err));
  }
  onSubmit(myForm) {
    this.pin = myForm["pin"];
    console.log(this.pin);
    localStorage.setItem('pin', this.pin);
    this.service.getPin(this.pin).subscribe(resp => { this.pinResponse = resp; console.log(this.pinResponse); localStorage.setItem('interviewtime', resp['timetaken']); localStorage.setItem('InterviewId', resp['interviewId']); localStorage.setItem('status', resp['status']) }, err => console.log(err));
  }
  myFormGroup() {
    return new FormGroup({
      pin: new FormControl()
    })
  }

  logout()  {
    this.api.logout();
    this.router.navigate(['/login']);
  }



}
